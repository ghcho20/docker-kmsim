#!/bin/bash

if [ $# != 3 ] ; then
	echo "usage: $0 mySysName myManagement_IP KEMS_IP my_mgmt_ip ex) $0 KMSM 192.168.86.234 192.168.86.230"
	exit
fi

echo "setup KMS PKG V2.1.1"

M_SYS=$1
MY_MGMT_IP=$2
ADMIN_IP=$3

DB_TEMPLETE_FILE="./DB/init_db.sql.templete"
SYSCONFIG_TEMPLETE_FILE="./config/sysconfig.templete"

# sysconfig
sed -e "s|%SYS_NAME%|$M_SYS|" < $SYSCONFIG_TEMPLETE_FILE > ./config/sysconfig

# db
sed -e "s|%SYS_NAME%|$M_SYS|" -e "s|%ADMIN_IP%|$ADMIN_IP|" -e "s|%MGMT_IP%|$MY_MGMT_IP|" < $DB_TEMPLETE_FILE > ./DB/init_db.sql

cd ./DB
sqlite3 kms.db < init_db.sql

echo "complete..."
