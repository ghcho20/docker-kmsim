# master / slave 구분 없이 동작
# [-o home path]  [-p provision ] [-q qkd key ] [-c ssl cert] [-k ssl key ] [-l log level] [-h]
#
# master org
# update kms_node set node_ip='192.168.11.10', node_port=60011 where node_id=3
#
# master sim
# update kms_node set node_ip='192.168.11.50', node_port=60021 where node_id=3
#
# slave org
# update kms_node set node_ip='192.168.11.20', node_port=60012 where node_id=3
#
# slaver sim
# update kms_node set node_ip='192.168.11.50', node_port=60022 where node_id=3
#
# arm master org
# update kms_node set node_ip='192.168.11.10', node_port=60011 where node_id=3
# arm master smi
# update kms_node set node_ip='192.168.85.162', node_port=60031 where node_id=3
# arm slave org
# update kms_node set node_ip='192.168.11.20', node_port=60012 where node_id=3
# arm slave smi
# update kms_node set node_ip='192.168.85.162', node_port=60032 where node_id=3
./sim_qkd_skt -l 3 &
