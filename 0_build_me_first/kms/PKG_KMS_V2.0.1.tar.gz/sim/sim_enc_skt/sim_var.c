#include "sim.h"

//--------------------------------------------------------------------------
// External Variable Definition
//--------------------------------------------------------------------------
int   myQid, abrkQid;
int   trcFlag;
char  mySysName[SYSCONF_MAX_NAME_LEN], myAppName[SYSCONF_MAX_NAME_LEN], app_home[SYSCONF_MAX_MIDDLE_NAME_LEN];        
char  l_sysconf[64];
char  resBuf[SYSCONF_MAX_MIDDLE_BUF_LEN], resHead[SYSCONF_MAX_SHORT_BUF_LEN], resBody[SYSCONF_MAX_MIDDLE_BUF_LEN];
int		gIsManagementMode, gTid;
unsigned int    gKeyspMessageSeq;
time_t  currentTime;
cryptKeyInfo	cryptKey;

char    provision[256], cert[256], key[256], homePath[256];
int     logLevel, operMode;
int     gPollingInterval;
int     gTimeoutRetry, tKeepalive, tRequest;
int     gReportingInterval;
int             gEncCtxCnt;                         // encCtxTbl 개수
agtCtx          encCtxTbl[SYSCONF_MAX_NODE_NUM];


