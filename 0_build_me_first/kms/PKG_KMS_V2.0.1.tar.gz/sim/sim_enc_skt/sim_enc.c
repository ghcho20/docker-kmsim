#include "sim.h"


int main(int argc, char **argv)
{

	int 	ret;
	time_t	t1, t5, tR, tK;

	currentTime = tK = tR = t1 = t5 = time(NULL);

	// -----------------------------------------------------------
	// 0. 초기화 작업
	// -----------------------------------------------------------
	if ((ret = sim_init(argc, argv)) < 0) {
		fprintf(stderr, "[main] >>>>>>> %s initial fail \n", myAppName);
		exit(1);
	}


	// -----------------------------------------------------------
	// 1. 주기적으로 반복하는 작업
	// -----------------------------------------------------------
	while(1) 
	{
		currentTime = time(&currentTime);

		// -----------------------------------------------------------
		// 1.2 socket 에 들어온 데이터 검사 (응답을 검사한다.)
		// -----------------------------------------------------------
		sim_exeRxSocketEvent();

        if ((currentTime-t1) >= 1)
        {
         	t1 = currentTime;
			sim_register();
		}

		//-------------------------------------------------------------
        // 1.4 5초 단위로 connection 검사 
        //-------------------------------------------------------------
        if ((currentTime-t5) >= 5)
        {
         	t5 = currentTime;
			sim_checkConnections();
		}

        if ((currentTime-tK) >= tKeepalive)
        {
         	tK = currentTime;
			sim_keepalive();
		}

		if(operMode == MASTER) {
        	if ((currentTime-tR) >= tRequest)
        	{
         		tR = currentTime;
				sim_request();
			}
		}
		else {
			sim_request();
		}
		
		commlib_microSleep(10);
	}

	return 0;
}
