#ifndef _KMCORE_H_
#define _KMCORE_H_

#include <stdio.h>
#include <stdlib.h>

#include <getopt.h>
#include <string.h>
#include <strings.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <sqlite3.h>

#include "commlib.h"
#include "sysconf.h"
#include "comm_msgtypes.h"
#include "slib_sock.h"
#include "slib_thread_pool.h"
#include "keysp.h"


#define simLog(_LEVEL,fmt,...){\
	int d_level =  0;\
	d_level = logLevel;\
	if((_LEVEL) >= d_level){\
  		logPrint(appLogId,__FILE__,__LINE__,__func__,_LEVEL,fmt,##__VA_ARGS__);\
	}\
}


//--------------------------------------------------------------------------
// External Variable Definition
//--------------------------------------------------------------------------
extern int   rtmdQid, myQid, abrkQid;
extern char  mySysName[SYSCONF_MAX_NAME_LEN], myAppName[SYSCONF_MAX_NAME_LEN], app_home[SYSCONF_MAX_MIDDLE_NAME_LEN];        
extern char  l_sysconf[64];
extern char  resBuf[SYSCONF_MAX_MIDDLE_BUF_LEN], resHead[SYSCONF_MAX_SHORT_BUF_LEN], resBody[SYSCONF_MAX_MIDDLE_BUF_LEN];
extern int		gIsManagementMode, gTid;
extern unsigned int    gKeyspMessageSeq;
extern time_t  currentTime;
extern cryptKeyInfo    cryptKey;


// OPTION
#define     MASTER 0
#define		SLAVE  1

#define		DEFAULT_HOME		"./"
#define		DEFAULT_PROVISION	"provision.enc"
#define		DEFAULT_CERT		"cert.pem"
#define		DEFAULT_KEY			"key.pem"
#define		DEFAULT_LOGLEVEL	LD
#define		DEFAULT_OPMODE		MASTER

extern char	provision[256], cert[256], key[256], homePath[256];
extern int		logLevel, operMode;

// -----------------------------------------------------------------------------
// connect 장비 정보 
// -----------------------------------------------------------------------------

#define SOCK_RECONNECT_INTERVAL       5   // 연결이 끊어지고 이 시간이상 지났으면 다시 연결
#define SOCK_CONN_CHECK_PERIOD      60 // 이시간동안 송수신 메시지가 없으면 끊는다.
#define SOCK_RECV_TIMEOUT_RETRY       5   // 응답없을을 한번에 발생시키지 않고 이 회수까지 대기

// tcp 정보 수집을 몇초 단위로 할 지
#define SOCK_DEFAULT_TIMEOUT 			5
#define SOCK_DEFAULT_KEEPALIVE_INTERVAL 5
#define SOCK_DEFAULT_POLLING_INTERVAL 	5
extern int		gPollingInterval;
extern int		gTimeoutRetry, tKeepalive, tRequest;
extern int		gReportingInterval;

pthread_mutex_t ctxLock;







typedef struct {
	uint			nEncNodeID;		/* Encrypter 의 node id */	
	               		            /* QKD에서 수신한 경우  dstNodeId , QKD로 전송한 경우 srcNodeId */
	               	   		        /* KMS에서 수신한 경우  srcNodeId , KMS로 전송한 경우 dstNodeId */
	// qkd host info
	uint 	    	nQkdNodeID;     /* QKD Node ID */
	uint			nPeerNodeID;
	char    		szIp[SYSCONF_MAX_IP_LEN];
	int				nPort;
	int				nTimeout;			/* 타임아웃 시간 sec */
	int				nKeepaliveInterval;	/* keepalive 간격  sec */
	int				nRetryLimit;		/* 몇번까지 재시도 할 것 인가 */
	
	// ssl
	char    		certFile[SYSCONF_MAX_LONG_NAME_LEN];
	char  			keyFile[SYSCONF_MAX_LONG_NAME_LEN];
	SSL_CTX     	*ctx;
	SSL         	*ssl;

	// socket info
	int     		fd;         	/* remote system으로 접속한 송신용 socket fd */
	time_t  		disconnTime;    /* 접속이 끊어진 시각 -> 재접속하기 전에 interval을 두기위해 */
	struct  sockaddr_in	srvAddr;
	int				nRetry;			/* 전송 실패시 ++ 한다 전송 성공하면 0 */
	int				nTimeoutCnt;	/* 수신 실패시 ++ 한다 수신 성공하면 0 */

	// socket 기준
	time_t  		lastSTxTime;    /* 마지막으로 메시지를 QKD로 보낸 시각 -> 주기적인 connection check를 위해 */
	time_t  		lastSRxTime;    /* 마지막으로 메시지를 QKD에서 수신한 시각 -> 주기적인 connection check를 위해 */
	// msgQ 기준
	time_t  		lastQTxTime;    /* 마지막으로 메시지를 KMSD로 보낸 시각 */
	time_t  		lastQRxTime;    /* 마지막으로 메시지를 KMSD에서 수신한 시각 */

	int				nKeepAliveSeq;	// keepalive 메시지 만들때 사용

	int				isResponse;
	int				isRegister;
} agtCtx;

extern int         	gEncCtxCnt;           				// encCtxTbl 개수 
extern agtCtx   		encCtxTbl[SYSCONF_MAX_NODE_NUM];




/* sim_enc.c */
extern int main(int argc, char **argv);
/* sim_init.c */
extern int sim_getArgs(int ac, char *av[]);
extern int sim_initLog();
extern int sim_initConnections();
extern int sim_init(int ac, char *av[]);
/* sim_proc.c */
extern int sim_loadConfig();
extern void sim_syncSlave(int peer, int keyid);
extern int sim_getSlaveKeyId(int peer);
extern char *sim_getCtxIdentity(agtCtx *info, char *szRet);
extern int sim_disconnectSockFd(int fd);
extern int sim_getCtxIdxByFd(int fd);
extern int sim_checkConnections();
extern int sim_connect2Remote(int index);
extern void sim_register();
extern void sim_keepalive();
extern int sim_getNextKeepaliveState(int i);
extern void sim_request();
extern void sim_confirm(int i, int keyId);
extern int sim_sendSocketMsg(int nCtxIdx, int nLen, unsigned char *szMsg);
extern int sim_getCtxIdxByNodeId(int nEncNodeId, int nQkdNodeId);
/* sim_recvSMsg.c */
extern void sim_exeRxSocketEvent();
extern int sim_exeSMsg(int nCtxIdx, int nLen, unsigned char *szRxData);
extern int sim_procSMsg(keyspCtx rxMsg, int nLen);
/* sim_var.c */

#endif //  _KMCORE_H_
