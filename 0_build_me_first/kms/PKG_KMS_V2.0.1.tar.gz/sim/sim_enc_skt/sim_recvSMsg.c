#include "sim.h"
// ------------------------------------------------------------------
// socket event 처리
// ------------------------------------------------------------------
void sim_exeRxSocketEvent()
{
	int             ret, actFd=0, nCtxIdx=0, nRxLen=0, bodyLen, headLen, idx;
	keyspHeader     *head;
	char            remoteAddr[32];
	unsigned char   rxSockMsg[KEYSP_MAX_BODY_LEN];
	
	memset(rxSockMsg,   0x00,   sizeof(rxSockMsg));

	/* keysp 은 일반적 처리가 불가능해 header 읽고 body 길이 계산해서 body 읽기 한번 더 호출한다. */
	nRxLen = KEYSP_HEAD_LEN;

	ret = slib_action (&nRxLen, (char*)&rxSockMsg, &actFd);
	
	switch (ret) {
		// equip 로부터 메시지를 수신한 경우
		case SLIB_SERVER_MSG_RECEIVED:
			/* header에 있는 length field를 꺼낸다.  */
			if (nRxLen == KEYSP_HEAD_LEN && (idx = slib_findServerIdxByFd(actFd)) >= 0) {
				head 		= (keyspHeader*)rxSockMsg;
				headLen 	= ntohl(head->nLen);	// head len + body len
				bodyLen 	= headLen - KEYSP_HEAD_LEN;

				snprintf (remoteAddr, SYSCONF_MAX_IP_LEN, "%s", inet_ntoa(serverSockFdTbl[idx].srvAddr.sin_addr));
				nRxLen += slib_readSockFdV2 (&bodyLen, (char *)&rxSockMsg[nRxLen], actFd, remoteAddr , serverSockFdTbl[idx].ssl);
			}

			if ( ( nCtxIdx = sim_getCtxIdxByFd(actFd) ) < 0) {
				simLog(LE, "received invaild fd=%d\n", actFd);
				return ;
			}
			sim_exeSMsg (nCtxIdx, nRxLen, rxSockMsg);
			break;
			
		case SLIB_SERVER_DISCONNECTED:
			// socket table에서 삭제한다.
			sim_disconnectSockFd (actFd);
			break;
		case SLIB_NO_EVENT:
			// simLog (LW,"[%s] SOCK_NO_EVENT event(%d) \n",FN,ret);                                                        
			break;                                                                                                          
		case SLIB_INTERNAL_ERROR:                                                                                           
			// simLog (LW,"[%s] SOCK_INTERNAL_ERROR event(%d) ctxIdx(%d) \n",FN,ret, nCtxIdx);                              
			break;                                                                                                          
		default:                                                                                                            
			simLog (LW,"[%s] not implement sock event(%d) fd=%d not implement\n",FN,ret, actFd);                      
			break;                                                                                                          
	}                                                                                                                   
	
}//-- End of sim_exeRxSocketEvent() --// 

//------------------------------------------------------------------------------
// QKD에서 받은 socket 메시지 처리
//------------------------------------------------------------------------------
int sim_exeSMsg (int nCtxIdx, int nLen, unsigned char *szRxData)
{
	keyspCtx	rxMsg;


	memset(&rxMsg,		0x00,		sizeof(keyspCtx));
	memcpy(&rxMsg.head,	szRxData, 	nLen);

	simLog (LI,"received SocketMsg[resp]ctx=%d msgId=%d (%d->%d)\n",
			nCtxIdx, ntohs(rxMsg.body.op_code), 
			ntohl(rxMsg.head.nSrcNodeId), ntohl(rxMsg.head.nDstNodeId));
	simLog(LD,"received msgLen(%d) msg=\n%s\n\n",nLen, comlib_printHexNLine(8,nLen, (unsigned char *)szRxData));


	// 수신 메시지 처리
	switch (ntohs(rxMsg.body.op_code)) {
		case MSGID_SKT_KEYSP_REGISTRATION :
		case MSGID_SKT_KEYSP_UNREGISTRATION :
		case MSGID_SKT_KEYSP_KEEPALIVE :
		case MSGID_SKT_KEYSP_KEY_REQUEST :
		case MSGID_SKT_KEYSP_CONFIRM :

		case MSGID_SKT_KEYSP_ACK_REGISTRATION :
		case MSGID_SKT_KEYSP_ACK_UNREGISTRATION :
		case MSGID_SKT_KEYSP_KEY_RESPONSE :
		case MSGID_SKT_KEYSP_KEY_REQUEST_ENC :
		case MSGID_SKT_KEYSP_ACK_ENC :

		case MSGID_SKT_KEYSP_CONFIRM_REQUEST_ENC :
			sim_procSMsg(rxMsg, nLen);
			break;


		default :
			simLog(LE,"unknown msg_id(0x%02X)\n", ntohs(rxMsg.body.op_code));
		break;
	}

	return 1;

} //----- End of sim_exeSMsg() -----//

// --------------------------------------------------------------------------
// SKT KEYSP QKD response 처리 (socket keysp -> msgQ json)
//  - keysp 프로토콜로 들어 오는 socket 메시지를  json 메시지로 변환 msgQ 전송
// --------------------------------------------------------------------------
int sim_procSMsg(keyspCtx rxMsg, int nLen)
{
	int		nEncNodeId,nQkdNodeId,nCtxIdx;
	char    szJson[SYSCONF_JSON_MSG_MAX_LEN];

	memset(szJson,	0x00,	sizeof(szJson));
	

	// ------------------------------------------------
	// 1. msg parser
	//    keysp 메시지를 json 으로
	// ------------------------------------------------
	if (keysplib_parserKeyspToJson( KMS_KEY_NONE, cryptKey, rxMsg, szJson) < 0) {
		simLog(LE,"invaild keysp msg=\n%s\n",comlib_printHexNLine(8,nLen, (unsigned char *)&rxMsg.head) );
		// error return (qkd의 응답 메시지에  대한 error 리턴은 없다)
		return -1 ;
	}


	nEncNodeId = ntohl(rxMsg.head.nDstNodeId);
	nQkdNodeId = ntohl(rxMsg.head.nSrcNodeId);
	if((nCtxIdx = sim_getCtxIdxByNodeId(nEncNodeId, nQkdNodeId)) < 0) {
		simLog(LE,"not management node err(%d) Enc=%ld Qkd=%ld\n", nCtxIdx, nEncNodeId, nQkdNodeId);
		return  -1;
	}

	// simLog(LD,"keysp msg convert(%s)\n\n",szJson );

	// 수신 메시지 처리
	switch (ntohs(rxMsg.body.op_code)) {
		case MSGID_SKT_KEYSP_ACK_REGISTRATION :
			encCtxTbl[nCtxIdx].isRegister = 1;
			break;
		case MSGID_SKT_KEYSP_KEY_RESPONSE :
			encCtxTbl[nCtxIdx].isResponse = 1;

			if(ntohl(rxMsg.body.req.result) == 0) {
				sim_syncSlave(encCtxTbl[nCtxIdx].nPeerNodeID, ntohl(rxMsg.body.req.nKeyId));

				// sim_confirm(nCtxIdx, ntohl(rxMsg.body.req.nKeyId));
			}
			simLog(LI,"key Response result=%d keyid=%d key=%s\n\n", ntohl(rxMsg.body.req.result), 
					ntohl(rxMsg.body.req.nKeyId), comlib_printHex2(128,rxMsg.body.req.szKey) );

			break;
	}

	encCtxTbl[nCtxIdx].lastSRxTime = currentTime;

	return 1;
}

