/* sim_enc.c */
extern int main(int argc, char **argv);
/* sim_init.c */
extern int sim_getArgs(int ac, char *av[]);
extern int sim_initLog(void);
extern int sim_initConnections(void);
extern int sim_init(int ac, char *av[]);
/* sim_proc.c */
extern int sim_loadConfig(void);
extern void sim_syncSlave(int peer, int keyid);
extern int sim_getSlaveKeyId(int peer);
extern char *sim_getCtxIdentity(agtCtx *info, char *szRet);
extern int sim_disconnectSockFd(int fd);
extern int sim_getCtxIdxByFd(int fd);
extern int sim_checkConnections(void);
extern int sim_connect2Remote(int index);
extern void sim_register(void);
extern void sim_keepalive(void);
extern int sim_getNextKeepaliveState(int i);
extern void sim_request(void);
extern void sim_confirm(int i, int keyId);
extern int sim_sendSocketMsg(int nCtxIdx, int nLen, unsigned char *szMsg);
extern int sim_getCtxIdxByNodeId(int nEncNodeId, int nQkdNodeId);
/* sim_recvSMsg.c */
extern void sim_exeRxSocketEvent(void);
extern int sim_exeSMsg(int nCtxIdx, int nLen, unsigned char *szRxData);
extern int sim_procSMsg(keyspCtx rxMsg, int nLen);
/* sim_var.c */
