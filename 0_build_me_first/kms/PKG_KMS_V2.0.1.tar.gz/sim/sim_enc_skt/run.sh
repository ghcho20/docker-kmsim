# [-o home path]  [-p provision ] [-m operMode  (Master|Slave) ] [-c ssl cert] [-k ssl key ] [-l log level] [-h]
#
# Master org
# update kms_node set node_port=60011 where node_id=1
# update kms_node set APP_NAME='KMSD' where node_id=4
#
# Master sim
# update kms_node set node_port=70011 where node_id=1
# update kms_node set APP_NAME='PAGT' where node_id=4
#
# Slave org
# update kms_node set node_port=60012 where node_id=1
#
# Slave sim
# update kms_node set node_port=70012 where node_id=1

./sim_enc_skt -m M -l 1
./sim_enc_skt -m S -l 1
