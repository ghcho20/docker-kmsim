#include "sim.h"

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
int sim_getArgs (int ac, char *av[])
{
	int		a;
	char	*usage =
	" [-o home path] [-m mode]  [-p provision ] [-c ssl cert] [-k ssl key ] [-l log level] [-h] \n\
           -o home path \n\
		   -m operation mode (Master | Slave) \n\
           -p provision config file \n\
           -c ssl Certificate file\n\
           -k ssl key file \n\
           -l log level (1~4) \n\
           -h : help\n\n";

	strcpy(homePath,	DEFAULT_HOME);
	sprintf(provision,	"%s/config/%s",homePath, DEFAULT_PROVISION);
	sprintf(cert,		"%s/config/%s",homePath, DEFAULT_CERT);
	sprintf(key,		"%s/config/%s",homePath, DEFAULT_KEY);
	logLevel	= DEFAULT_LOGLEVEL;
	operMode	= DEFAULT_OPMODE;

	while ((a = getopt(ac,av,"o:m:p:c:k:l:h")) != EOF)
	{
		switch (a) {
			case 'o':
				sprintf (homePath,"%s", optarg);
				break;
			case 'm':
				if(optarg[0] == 'M') operMode = MASTER;
				else operMode = SLAVE;
				break;
			case 'p':
				sprintf (provision,"%s/config/%s",homePath, optarg);
				break;
			case 'c':
				sprintf (cert,"%s/config/%s",homePath,optarg);
                break;
			case 'k':
				sprintf (key,"%s/config/%s",homePath,optarg);
				break;
			case 'l':
				logLevel = atoi (optarg);
				break;
			case 'h':
			default:
				fprintf(stderr,"%s",usage);
				return -1;
		}
	}

	if (optind < ac) {
		fprintf(stderr,"%s",usage);
		return -1;
	}

	return 1;

} //----- End of sim_getArgs -----//

// -----------------------------------------------------------------------
// log file init
// -----------------------------------------------------------------------
int sim_initLog(void)
{
    LoglibProperty  property;

	memset(&property, 0, sizeof(property));
	property.mode = LOGLIB_MODE_LIMIT_SIZE | LOGLIB_FLUSH_IMMEDIATE |
			        LOGLIB_TIME_STAMP | LOGLIB_FNAME_LNUM | LOGLIB_LOG_LEVEL;
	property.num_suffix = 0;
	property.limit_val = 0;

	sprintf(property.fname,"./log/%s", __progname);

    if ((appLogId = loglib_openLog (&property)) < 0) {
        fprintf (stderr, "[%s] openLog fail[%s]\n", __func__, property.fname);
        return -1;
    }

    return 0;
}//-- End of sim_initLog() --//


// ------------------------------------------------------------
// QKD 장비 정보를 읽고 초기 접속 시도를 한다.
// ------------------------------------------------------------
int sim_initConnections()
{
	int i;

	// -----------------------------------------------------
	// 0. 메모리 초기화
	// -----------------------------------------------------
	memset(encCtxTbl, 	0x00, sizeof(encCtxTbl));
	for(i=0; i<SYSCONF_MAX_NODE_NUM; i++) {
	   	encCtxTbl[i].fd 	= -1;
	}

	// ------------------------------------------------------------------------
	// 1. 장비를 읽어 온다. (qkd 장비가 tcp server / enc 장비가 tcp client))
	//    프로비젼 정보를 KMS DBMS에 요청 한다.
	// ------------------------------------------------------------------------
	gEncCtxCnt = 0;

	// config 읽기
	sim_loadConfig();

	// -----------------------------------------------------
	// 2. tcp init
	// -----------------------------------------------------
	slib_initial();
	slib_setSockMode   (eSockModeUdp);

	// -----------------------------------------------------
	// 3. qkd 장비에 접속 시도 한다.
	// -----------------------------------------------------
	sim_checkConnections();

	return 0;

} //-- End of sim_initTcpClient() --//



int sim_init(int ac, char *av[])
{
	// sequence number
	gKeyspMessageSeq = 0;

	if (sim_getArgs(ac, av) < 0) {
		fprintf(stderr,"[%s] sim_getArgs() error\n", __func__);
        return -1;
	}

	pthread_mutex_init(&ctxLock, NULL);

	commlib_upperProgname (myAppName);

	commlib_setupSignals (NULL);

    if (sim_initLog () < 0) {
		fprintf(stderr,"[%s] sim_initLog() error\n", __func__);
        return -1;
	}

	//  DTLS
	if (sim_initConnections() < 0) {
		fprintf(stderr,"[%s] sim_initConnections() error\n", __func__);
		return -1;
	}

	// magic Crypto
	if (iv_Initialize() < 0) {
		fprintf(stderr, "iv_Initialize() fail\n");
		return -1;
	}

    simLog (LE, "%s Start ............\n", myAppName);

	return 0;
}//-- End of sim_init() --//
