#include "sim.h"


int sim_loadConfig()
{
	int		i=0; 
	FILE	*fp;
	char	buf[2048], szMode[8];

	if((fp=fopen(provision, "r")) == NULL) {
		printf("open file %s fail [%s]\n", provision, strerror(errno));
		return -1;
	}

	while(fgets(buf, sizeof(buf),fp) != NULL && (i <SYSCONF_MAX_NODE_NUM)) {
		if(strlen(buf) == 0 || buf[0] == '#') continue ;

		memset(szMode, 0x00, sizeof(szMode));
		sscanf(buf,"%s ", szMode);

		if (operMode == MASTER && strcasecmp(szMode,"M") != 0) continue;
		else if (operMode == SLAVE && strcasecmp(szMode,"S") != 0) continue;

		sscanf(buf,"%s %d %d %d %s %d %d %d",
			szMode,
			&encCtxTbl[i].nEncNodeID,
			&encCtxTbl[i].nQkdNodeID,
			&encCtxTbl[i].nPeerNodeID,
			encCtxTbl[i].szIp,
			&encCtxTbl[i].nPort,
			&tKeepalive, &tRequest);

		strcpy(encCtxTbl[i].certFile,cert);
		strcpy(encCtxTbl[i].keyFile, key);

		simLog(LD,"(%d) enc=%d, qkd=%d, peer=%d, ip=%s, port=%d, cert=%s, key=%s\n",
			i, encCtxTbl[i].nEncNodeID,encCtxTbl[i].nQkdNodeID, encCtxTbl[i].nPeerNodeID, 
			encCtxTbl[i].szIp,encCtxTbl[i].nPort,
			encCtxTbl[i].certFile,encCtxTbl[i].keyFile);
		i++;
	}

	gEncCtxCnt	=	i;	

	return 0;
}//-- End of sim_procProvisionMsg() --//


void sim_syncSlave(int peer, int keyid)
{
	FILE *fp;
	char szFname[256], szFname2[256];

	pthread_mutex_lock(&ctxLock);

	sprintf(szFname, "%s/config/_peer_%d", homePath, peer);
	sprintf(szFname2, "%s/config/peer_%d", homePath, peer);

	if ((fp = fopen(szFname, "w")) != NULL) {
		fprintf(fp,"%d", keyid);
		fclose(fp);
	}

	rename(szFname,szFname2);

	pthread_mutex_unlock(&ctxLock);

}

int sim_getSlaveKeyId(int peer)
{
	FILE *fp;
	char szFname[256];
	int	 keyid = 0;

	pthread_mutex_lock(&ctxLock);

	sprintf(szFname, "%s/config/peer_%d", homePath, peer);

	if ((fp = fopen(szFname, "r")) != NULL) {
		fscanf(fp,"%d", &keyid);
		fclose(fp);
		unlink(szFname);
	}
	else {
		pthread_mutex_unlock(&ctxLock);
	   	return 0;
	}

	pthread_mutex_unlock(&ctxLock);
	simLog(LI,"operMode=%s syncFile=%s keyId=%d\n", (operMode==MASTER)? "Master":"Slave", szFname, keyid);

	return keyid;
}

char *sim_getCtxIdentity(agtCtx *info, char *szRet)
{
	if (info) sprintf(szRet,"E:Q(%d-%d)", info->nEncNodeID,info->nQkdNodeID);
	return szRet;
}

// -----------------------------------------------------
// provider contents 정리 
// -----------------------------------------------------
int sim_disconnectSockFd(int fd)
{
	int encIdx;

	slib_disconnectSockFd (fd);

	if ( ( encIdx = sim_getCtxIdxByFd(fd) ) < 0) {
		simLog(LE, "received invaild fd=%d\n", fd);
		return ;
	}

	// 1. encCtxTbl에서 fd에 대한 정보를 삭제한다.
	encCtxTbl[encIdx].disconnTime	= currentTime;
	encCtxTbl[encIdx].fd            = 0;

	return 0;
}


int sim_getCtxIdxByFd(int fd)
{
	int i;

	for(i=0; i<gEncCtxCnt && i<SYSCONF_MAX_NODE_NUM; i++)
		if (encCtxTbl[i].fd == fd ) return i;

	return -1;

}//-- End of sim_getCtxIdxByFd() --//


/*------------------------------------------------------------------------------
* 1. sockRoutTbl을 확인하여 아직 접속되지 않은 remote로 접속한다.
* - 재접속을 시도할때 interval을 주기 위해 disconnect된 시각을 기록해 두고,
*	이를 확인하여 일정 시간이 지난 경우에만 재접속을 시도한다.
* - 접속되지 않는 경우 disconnect_time을 현재시각으로 update하여 정해진 interval
*	경과 후 재시도 하도록 한다.
* 2. 일정시간동안 수신 메시지가 없으면 송수신 port를 모두 강제로 끊는다.
------------------------------------------------------------------------------*/
int sim_checkConnections (void)
{
	int		i, fd;
	agtCtx	*ctx;
	char	szTmp[SYSCONF_MAX_LONG_NAME_LEN], *p1=NULL,*p2=NULL,*p3=NULL;

	simLog(LD,"Start connection check ctxNum=%d\n",gEncCtxCnt);

	for (i=0; i<gEncCtxCnt; i++)
	{
		ctx = &encCtxTbl[i];

		/* 접속되어 있지 않고, 재접속 interval이 지났으면 재접속 시도
		*/
		if ((ctx->fd <= 0) && ((currentTime - ctx->disconnTime) > SOCK_RECONNECT_INTERVAL))
		{
			sim_connect2Remote(i);
		}

		/* 일정시간동안 송수신 메시지가 없으면 송수신 port를 모두 강제로 끊는다.
		* - 초기 접속 시 remote에서도 SOCK_RECONNECT_INTERVAL을 주기로 재접속을
		*	시도하므로 최대 SOCK_CONN_CHECK_PERIOD + SOCK_RECONNECT_INTERVAL 동안
		*	수신 port에서 메시지를 받지 못할 수 있다.
		*/
		if (ctx->fd > 0 &&
			(((currentTime - ctx->lastSRxTime) > SOCK_CONN_CHECK_PERIOD) ||
			((currentTime - ctx->lastSTxTime) > SOCK_CONN_CHECK_PERIOD)))
		{
			fd = ctx->fd;
			sim_disconnectSockFd (i); /* disconnect rx_port */
			ctx->fd = 0; /* clear rx_port */

			simLog(LE,"not received any msg from QKD=(%s) force disconnect(Fd=%d)\n"
			   " rxTime=(%s) txTime=(%s) curTime=(%s)\n",
				sim_getCtxIdentity(ctx, szTmp), fd,
				(p1=commlib_mprintDateTime(ctx->lastSRxTime)), 
			   	(p2=commlib_mprintDateTime(ctx->lastSTxTime)),
				(p3=commlib_mprintDateTime(currentTime)));
			commlib_free(p1);
			commlib_free(p2);
			commlib_free(p3);
		}
	}
	simLog(LD,"End connection check ctxNum=%d\n",gEncCtxCnt);

	return 1;

} /** End of sim_checkConnections **/



/*------------------------------------------------------------------------------
* 등록된 address로 접속시도한다.
* - 접속되면 송신port를 저장하고, connection check를 위한 lastTxTime에 현재시각을
*	기록한다.
* - 접속실패시 일정시간(IXPC_RECONNECT_INTERVAL) 경과 후 재시도하도록 하기위해
*	disconnTime에 현재시각을 기록한다.
------------------------------------------------------------------------------*/
int sim_connect2Remote (int index)
{
	int		fd;
	agtCtx	*enc = &encCtxTbl[index];
	char	szTmp[SYSCONF_MAX_LONG_NAME_LEN];

	if ((fd = slib_connect ( enc->szIp, enc->nPort, enc->certFile, enc->keyFile)) >= 0) {
		simLog(LI,"connect to ctx=%d %s fd=%d\n",index, sim_getCtxIdentity(enc, szTmp), fd);

		if (fd > 500) {
			simLog(LE,"connect fd=%d wrong ctx=%d %s\n", fd, index, sim_getCtxIdentity(enc, szTmp));
			exit(1);
		}

		enc->fd			= fd;
		enc->lastSTxTime= currentTime;
		enc->lastSRxTime= currentTime;
		return 1;
	}
	
	// ---------------------------------------------------------------------
	// connect fail
	// ---------------------------------------------------------------------
	simLog(LE,"connect fail ctx=%d %s\n",index, sim_getCtxIdentity(enc, szTmp));

	/* update disconnect time stamp -> 재접속 interval을 위해
	*/
	enc->disconnTime 			= currentTime;
	enc->fd	 					= -1;
	
	return -1;

} /** End of sim_connect2Remote **/




void sim_register()
{
	keyspCtx  		cnvtCtx;
	keyspArgs 		rxMsg;
	char			*p=NULL, szTmp[128];
	int				i, nLen, ret;

	for(i=0; i<gEncCtxCnt; i++) {

	if (encCtxTbl[i].isRegister) continue ;

	// ---------------------------------------
	// 1. keepalive 용 arg 메시지를 생성
	// ---------------------------------------
	memset(&rxMsg,	0x00,	sizeof(keyspArgs));

	rxMsg.nOpcode    	=	MSGID_SKT_KEYSP_REGISTRATION;
	rxMsg.nEncNodeId	=	encCtxTbl[i].nEncNodeID;
	rxMsg.nQkdNodeId	=	encCtxTbl[i].nQkdNodeID;
	rxMsg.nSeqNum		=	gKeyspMessageSeq;
	sprintf(rxMsg.szTransactionId, "%s", (p=keysplib_getTransactionId(MSGID_SKT_KEYSP_KEEPALIVE, currentTime,gKeyspMessageSeq++) ));
	commlib_free(p);

	// ---------------------------------------
	// 2. arg 메시지를 keysp 구조체에 넣는다.
	// ---------------------------------------
	if (keysplib_parserArgToKeysp(rxMsg, &cnvtCtx) < 0) {
		simLog(LE,"ctx=%d %s make fail keysp message\n", i, sim_getCtxIdentity(&encCtxTbl[i], szTmp) );
	}

	// -------------------------------------------------------------------------------
	// 4. request
	// -------------------------------------------------------------------------------
	nLen = ntohl(cnvtCtx.head.nLen);

 	if ((ret = sim_sendSocketMsg(i, nLen, (unsigned char *)&cnvtCtx.head)) < 0) {
		simLog(LE,"send error ret = %d \n", ret);
	}

	}
	return ;
}//-- End of sim_sendKeepalive() --//






void sim_keepalive()
{
	keyspCtx  		cnvtCtx;
	keyspArgs 		rxMsg;
	char			*p=NULL, szTmp[128];
	int				i, nLen, ret, nKeepaliveState = 0;

	for(i=0; i<gEncCtxCnt; i++) {

	if (!encCtxTbl[i].isRegister) continue ;

	if ((nKeepaliveState = sim_getNextKeepaliveState(i)) < 0) {
	   	continue ;
	}
	// ---------------------------------------
	// 1. keepalive 용 arg 메시지를 생성
	// ---------------------------------------
	memset(&rxMsg,	0x00,	sizeof(keyspArgs));

	rxMsg.nOpcode    	=	MSGID_SKT_KEYSP_KEEPALIVE;
	rxMsg.nEncNodeId	=	encCtxTbl[i].nEncNodeID;
	rxMsg.nQkdNodeId	=	encCtxTbl[i].nQkdNodeID;
	rxMsg.nSeqNum		=	gKeyspMessageSeq;
	rxMsg.nKeepaliveState		=	nKeepaliveState;
	rxMsg.nKeepaliveSeqNum		=	encCtxTbl[i].nKeepAliveSeq++;	
	sprintf(rxMsg.szTransactionId, "%s",(p=keysplib_getTransactionId(MSGID_SKT_KEYSP_KEEPALIVE, currentTime,gKeyspMessageSeq++) ));
	commlib_free(p);

	// ---------------------------------------
	// 2. arg 메시지를 keysp 구조체에 넣는다.
	// ---------------------------------------
	if (keysplib_parserArgToKeysp(rxMsg, &cnvtCtx) < 0) {
		simLog(LE,"ctx=%d %s make fail keysp message\n", i, sim_getCtxIdentity(&encCtxTbl[i], szTmp) );
	}

	// -------------------------------------------------------------------------------
	// 4. request
	// -------------------------------------------------------------------------------
	nLen = ntohl(cnvtCtx.head.nLen);
 	if ((ret = sim_sendSocketMsg(i, nLen, (unsigned char *)&cnvtCtx.head)) < 0) {
		simLog(LE,"send error ret = %d \n", ret);
	}

	}
	return ;
}//-- End of sim_sendKeepalive() --//


int sim_getNextKeepaliveState(int i)
{
	if (encCtxTbl[i].nKeepAliveSeq == 0) 
		return KEYSP_KEEPALIVE_STAE_DOWN;
	else
		return KEYSP_KEEPALIVE_STAE_UP;

}//-- End of sim_getNextKeepaliveState() --//



void sim_request()
{

	keyspCtx  		cnvtCtx;
	keyspArgs 		rxMsg;
	char			*p=NULL, szTmp[128];
	int				i, nLen, ret, keyId=0;

	for(i=0; i<gEncCtxCnt; i++) {
		if(operMode == SLAVE && (keyId=sim_getSlaveKeyId(encCtxTbl[i].nEncNodeID)) == 0) continue;

	// ---------------------------------------
	// 1. keepalive 용 arg 메시지를 생성
	// ---------------------------------------
	memset(&rxMsg,	0x00,	sizeof(keyspArgs));

	rxMsg.nOpcode    	=	MSGID_SKT_KEYSP_KEY_REQUEST;
	rxMsg.nEncNodeId	=	encCtxTbl[i].nEncNodeID;
	rxMsg.nQkdNodeId	=	encCtxTbl[i].nQkdNodeID;
	rxMsg.nSeqNum		=	gKeyspMessageSeq;
	rxMsg.nKeyId		=	keyId;
	sprintf(rxMsg.szTransactionId, "%s", (p=keysplib_getTransactionId(MSGID_SKT_KEYSP_KEEPALIVE, currentTime,gKeyspMessageSeq++) ));
	commlib_free(p);

	// ---------------------------------------
	// 2. arg 메시지를 keysp 구조체에 넣는다.
	// ---------------------------------------
	if (keysplib_parserArgToKeysp(rxMsg, &cnvtCtx) < 0) {
		simLog(LE,"ctx=%d %s make fail keysp message\n", i, sim_getCtxIdentity(&encCtxTbl[i], szTmp) );
	}

	// -------------------------------------------------------------------------------
	// 4. request
	// -------------------------------------------------------------------------------
	nLen = ntohl(cnvtCtx.head.nLen);

 	if ((ret = sim_sendSocketMsg(i, nLen, (unsigned char *)&cnvtCtx.head)) < 0) {
		simLog(LE,"send error ret = %d \n", ret);
	}


	encCtxTbl[i].isResponse = 0;

	}
	return ;

}

void sim_confirm(int i, int keyId)
{

	keyspCtx  		cnvtCtx;
	keyspArgs 		rxMsg;
	char			*p=NULL, szTmp[128];
	int				nLen, ret;


	// ---------------------------------------
	// 1. keepalive 용 arg 메시지를 생성
	// ---------------------------------------
	memset(&rxMsg,	0x00,	sizeof(keyspArgs));

	rxMsg.nOpcode    	=	MSGID_SKT_KEYSP_CONFIRM;
	rxMsg.nEncNodeId	=	encCtxTbl[i].nEncNodeID;
	rxMsg.nQkdNodeId	=	encCtxTbl[i].nQkdNodeID;
	rxMsg.nSeqNum		=	gKeyspMessageSeq;
	rxMsg.nKeyId		=	keyId;
	sprintf(rxMsg.szTransactionId, "%s", (p=keysplib_getTransactionId(MSGID_SKT_KEYSP_KEEPALIVE, currentTime,gKeyspMessageSeq++) ));
	commlib_free(p);

	// ---------------------------------------
	// 2. arg 메시지를 keysp 구조체에 넣는다.
	// ---------------------------------------
	memset(&cnvtCtx,  0x00,   sizeof(keyspCtx));
	if (keysplib_parserArgToKeysp(rxMsg, &cnvtCtx) < 0) {
		simLog(LE,"ctx=%d %s make fail keysp message\n", i, sim_getCtxIdentity(&encCtxTbl[i], szTmp) );
	}

	// -------------------------------------------------------------------------------
	// 4. request
	// -------------------------------------------------------------------------------
	nLen = ntohl(cnvtCtx.head.nLen);

 	if ((ret = sim_sendSocketMsg(i, nLen, (unsigned char *)&cnvtCtx.head)) < 0) {
		simLog(LE,"send error ret = %d \n", ret);
	}	

	return ;

}



int sim_sendSocketMsg(int nCtxIdx, int nLen,  unsigned char *szMsg)
{
	int ret = 0;
	int fd   = -1; 
	keyspHeader *head = (keyspHeader *)szMsg;
	keyspBody   *body = (keyspBody *)(szMsg+sizeof(keyspHeader));

	SSL *ssl = NULL;

	fd = encCtxTbl[nCtxIdx].fd;
	ssl= slib_findSSLByFd(fd);

	simLog(LI,"send ctx=%d msgId=%d (%d-%d)\n",nCtxIdx,ntohs(body->op_code), ntohl(head->nSrcNodeId), ntohl(head->nDstNodeId));

	simLog(LD,"send ctx=%d nLen=%d msg=\n%s\n\n",nCtxIdx, nLen, comlib_printHexNLine(8,nLen, (unsigned char *)szMsg));

	if((ret = slib_sndMsg(fd,  (char *)szMsg, nLen, ssl)) < 0) {
		simLog(LE,"openssl send error ctx=%d ret = %d len=%d\n", nCtxIdx, ret, nLen);
		return eSendFail;
	}

	encCtxTbl[nCtxIdx].lastSTxTime = currentTime;
	return ret;
} //-- End of sim_sendSocketMsg() */



int sim_getCtxIdxByNodeId(int nEncNodeId, int nQkdNodeId)
{
	int i;

	for(i=0; i<gEncCtxCnt && i<SYSCONF_MAX_QKD_NUM; i++)
		if (encCtxTbl[i].nQkdNodeID == nQkdNodeId && encCtxTbl[i].nEncNodeID == nEncNodeId) return i;

	return eNotManagementEnc;

}//-- End of pagt_getCtxIdxByNodeId() --//
