cproto -D_OPENSSL -I./ -I../../include \
		   -I../../libsrc/COMM \
		   -I../../libsrc/KEY \
		   -I../../libsrc/KEYSOCK \
		   -I../../libsrc/json-c-master \
		   -I../../libsrc/libuuid-1.0.3 \
		   -I../../libsrc/openssl-1.0.2n/include \
		   -I../../libsrc/OSSL \
	 -e sim_*.c > proto.h
