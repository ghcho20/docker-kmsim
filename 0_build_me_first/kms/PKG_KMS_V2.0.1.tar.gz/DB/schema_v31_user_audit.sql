DROP TABLE IF EXISTS "USER_AUDIT_LOG" ;
CREATE TABLE USER_AUDIT_LOG
(
	id        				integer primary key AUTOINCREMENT,
	USER_ID   				varchar(32),
	USER_TYPE				integer,
	CREATE_TIME 			datetime,
	JOB_TYPE   				varchar(32),
	RESULT      			varchar(32),
	CONTENT     			TEXT,
	REASON      			varchar(32),
	ACCESS_IP   			varchar(16)
) ;
