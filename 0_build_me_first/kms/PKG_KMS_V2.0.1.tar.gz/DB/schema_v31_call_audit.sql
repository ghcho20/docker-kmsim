DROP TABLE IF EXISTS "AUDIT_LOG" ;
CREATE TABLE AUDIT_LOG
(
    ID                      INTEGER PRIMARY KEY AUTOINCREMENT,
    SYS_NAME                VARCHAR(16),
    APP_NAME                VARCHAR(8),
    SRC_VID                 VARCHAR(32),
    TARGET_VID              VARCHAR(32),
    OP_TYPE                 INTEGER,
    RESULT_CODE             INTEGER,
    RESULT                  VARCHAR(128),
	PATH					VARCHAR(520),
    CREATE_TIME             TIMESTAMP,
    HMAC                    VARCHAR(64) 
) ;
