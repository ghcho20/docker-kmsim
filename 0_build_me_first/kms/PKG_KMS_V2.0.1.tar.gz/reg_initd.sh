#!/bin/sh

init_arm() {
    sed -e "s|%K_USER%|$K_USER|" -e "s|%K_HOME%|$K_HOME|"  < ${K_HOME}/config/S99kms.templete > /etc/init.d/S99kms
    chmod 755 /etc/init.d/S99kms
}

init_x86() {
    SYSTEMD=/usr/lib/systemd/system
    sed -e "s|%K_USER%|$K_USER|" -e "s|%K_HOME%|$K_HOME|"  < ${K_HOME}/config/kms.service.template > ${SYSTEMD}/kms.service
    systemctl enable kms
    systemctl start kms
    sudo -u $K_USER KMS_HOME=$K_HOME $K_HOME/bin/pman -d
}

if [[ "`whoami`" != "root" ]]; then
    echo "script must run under root"
    echo "abort..."
    exit
fi

if [ $# != 2 ] ; then
	echo "usage: $0 kms_user pkg_install_home_dir  ex) $0 kms /home/kms"
	echo "abort..."
	exit
fi

K_USER=$1
K_HOME=$2

case "`arch`" in
    x86_*)
        init_x86;;
    arm*)
        init_arm;;
esac

echo "complete..."
