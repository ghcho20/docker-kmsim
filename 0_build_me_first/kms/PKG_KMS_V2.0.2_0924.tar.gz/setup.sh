#!/bin/bash

if [ $# != 2 ] ; then
	echo "usage: $0 mySysName admin_IP  ex) $0 KMSM 1.1.1.2"
	exit
fi

echo "setup KMS PKG V2.0.2"

M_SYS=$1
#T_SYS=$2
#ADMIN_IP=$3
ADMIN_IP=$2

DB_TEMPLETE_FILE="./DB/init_db.sql.templete"
SYSCONFIG_TEMPLETE_FILE="./config/sysconfig.templete"

# sysconfig
sed -e "s|%SYS_NAME%|$M_SYS|" < $SYSCONFIG_TEMPLETE_FILE > ./config/sysconfig

# db
#sed -e "s|%SYS_NAME%|$M_SYS|" -e "s|%T_SYS_NAME%|$T_SYS|" -e "s|%ADMIN_IP%|$ADMIN_IP|" < $DB_TEMPLETE_FILE > ./DB/init_db.sql
sed -e "s|%SYS_NAME%|$M_SYS|" -e "s|%ADMIN_IP%|$ADMIN_IP|" < $DB_TEMPLETE_FILE > ./DB/init_db.sql

cd ./DB
sqlite3 kms.db < init_db.sql

#cd ./bin
#sudo chown root:root cagtn
#sudo chmod 6755 cagtn

echo "complete..."
